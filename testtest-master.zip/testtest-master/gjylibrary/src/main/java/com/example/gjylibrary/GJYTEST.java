package com.example.gjylibrary;

public class GJYTEST {
    public void PrintTest(){
        System.out.println("测试打印");
    }
}
